	let gamesLeft = 0;
	let spinResults = [];
	let totalFreebies = 0;
	let totalJackpots = 0;
	
	document.getElementById('playButton').addEventListener('click', playGame);
	document.getElementById('spinButton').addEventListener('click', spinSlots);
	document.getElementById('purchaseAmount').addEventListener('keypress', function(event) {
		if (event.key === 'Enter') {
			playGame();
		}
	});

	function playGame() {
	const purchaseAmount = parseInt(document.getElementById('purchaseAmount').value);
    fadeOut(document.getElementById('promptMessage'));

		if (isNaN(purchaseAmount) || purchaseAmount < 500) {
			showError('Please enter a valid amount of 500 PHP or more.');
			return;
		}

		gamesLeft = Math.floor(purchaseAmount / 500);
		document.getElementById('inputContainer').style.display = 'none';
		document.getElementById('gameContainer').style.display = 'block';
		document.getElementById('remainingSpins').innerText = `Remaining Spins: ${gamesLeft}`;
		}

		function showError(message) {
		document.getElementById('errorModalMessage').innerText = message;
		document.getElementById('errorModal').style.display = 'block';
		document.getElementById('purchaseAmount').value = '';
		}

		function closeErrorModal() {
		document.getElementById('errorModal').style.display = 'none';
		}

		function spinSlots() {
		if (gamesLeft <= 0) {
        showPrompt('No spins left! Please start a new game.', document.getElementById('promptMessage'));
        return;
		}

		document.getElementById('loadingSpinner').style.display = 'block';
		document.getElementById('spinButton').disabled = true;
		document.getElementById('spinSound').play(); 

		const slots = document.querySelectorAll('.slot');
		const spinInterval = 50;
		const spinTime = 1000;
		let spinCounter = 0;

		slots.forEach(slot => slot.classList.add('spin-animation'));

		const spinIntervalId = setInterval(() => {
        for (let i = 0; i < slots.length; i++) {
            const randomValue = Math.floor(Math.random() * 10);
            slots[i].innerText = randomValue;
        }
        spinCounter++;
        if (spinCounter * spinInterval >= spinTime) {
            clearInterval(spinIntervalId);
            checkWin(slots);
            slots.forEach(slot => slot.classList.remove('spin-animation'));
            document.getElementById('spinButton').disabled = false;
            document.getElementById('loadingSpinner').style.display = 'none';
        }
    }, spinInterval);
}

let totalPoints = 0;  // Track the total points earned throughout the game
function checkWin(slots) {
    const results = Array.from(slots).map(slot => parseInt(slot.innerText)); // Get the current spin results
    spinResults.push(results);
    gamesLeft--;

    const resultCombination = results.join(' | ');  // Format the result combination

    let modalMessage = `Your combination: ${resultCombination}<br>`;
    let isJackpot = results.every((val) => val === results[0]); // Jackpot if all numbers match
    let isFreebie = false;
    let isPointsConvertible = false;

    if (isJackpot) {
        totalJackpots++;
        modalMessage += 'Jackpot! You won a 40% Discount Coupon for your next purchase! 🎉';
        document.getElementById('jackpotIcon').style.display = 'inline';
        document.getElementById('jackpotsound').play();
        confetti(); // Trigger confetti animation
    } else {
        // Freebie condition: Exactly three matching numbers, one different
        const numberCounts = {};

        // Count occurrences of each number
        results.forEach(num => {
            numberCounts[num] = (numberCounts[num] || 0) + 1;
        });

        const counts = Object.values(numberCounts);
        if (counts.includes(3) && counts.includes(1)) {
            isFreebie = true;
            totalFreebies++;
            modalMessage += 'Congratulations, you have H-Mart item freebies! 🎁';
            document.getElementById('freebieIcon').style.display = 'inline';
            document.getElementById('winSound').play();
            confetti(); // Trigger confetti animation
        } else {
            modalMessage += 'Please Try Again!☹️';
            document.getElementById('jackpotIcon').style.display = 'none';
            document.getElementById('freebieIcon').style.display = 'none';
            document.getElementById('losesound').play();
        }

        // Track points for matching pairs
        const pairsCount = Object.values(numberCounts).filter(count => count >= 2).length;
        if (pairsCount >= 1) {
            totalPoints += pairsCount * 10;  // Award 10 points for each pair
            modalMessage += `<br>Points Earned: ${pairsCount * 10} points`;
        }
    }

    // Convert points to freebies
    const freebiesFromPoints = Math.floor(totalPoints / 50);
    if (freebiesFromPoints > 0) {
        totalFreebies += freebiesFromPoints;
        totalPoints %= 50; // Keep the remaining points after conversion to freebies
        modalMessage += `<br>You have earned ${freebiesFromPoints} freebies from points! 🎯`;
    }

    // Update remaining spins
    document.getElementById('remainingSpins').innerText = `Remaining Spins: ${gamesLeft}`;

    // Display the results in the modal
    document.getElementById('modalResultMessage').innerHTML = modalMessage;
    document.getElementById('resultModal').style.display = 'block'; // Show the result modal

    // Set modal button action
    document.getElementById('resultModal').querySelector('button').onclick = gamesLeft <= 0 ? showFinalResult : closeModal;
}


function closeModal() {
    document.getElementById('resultModal').style.display = 'none';
}

function showFinalResult() {
    document.getElementById('gameContainer').style.display = 'none';
    document.getElementById('resultContainer').style.display = 'block';

    // Calculate freebies from points and display the summary
    const freebiesFromPoints = Math.floor(totalPoints / 50);  // Calculate any remaining freebies
    let totalFreebiesIncludingPoints = totalFreebies + freebiesFromPoints;

    let summaryMessage = `<center>Total Spins: ${spinResults.length}<br>Total Jackpots: ${totalJackpots}<br>Total Freebies: ${totalFreebiesIncludingPoints}<br>Points Earned: ${totalPoints}</center>`;

    if (totalJackpots > 0 || totalFreebies > 0) {
        summaryMessage = '<center>CONGRATULATIONS<br>ON YOUR WINS! 🎉🎁</center>' + summaryMessage;
        document.getElementById('jackpotsound').play(); 
        confetti();
    }
    document.getElementById('summaryMessage').innerHTML = summaryMessage;
}


document.getElementById('returnButton').addEventListener('click', function() {
    location.reload();
});

function showPrompt(message, element) {
		element.innerText = message;
		element.classList.add('blink');
		fadeIn(element);
		setTimeout(() => {
        fadeOut(element);
		}, 3000);
	}

function fadeIn(element) {
    element.classList.add('show');
}

function fadeOut(element) {
    element.classList.remove('show');
    element.classList.remove('blink');
}

function togglePlayButton(enable) {
    document.getElementById('playButton').disabled = !enable;
}

// Call this in playGame and spinSlots where appropriate
togglePlayButton(false); // Disable when starting a game or spinning
togglePlayButton(true);  // Enable when game is over or spins are done

// Wait for the document to be ready
document.addEventListener("DOMContentLoaded", function() {
    const printButton = document.getElementById("printButton");

    // Add event listener to the print button
    printButton.addEventListener("click", function() {
        // Call the function to print only the result
        printResult();
    });

    // Function to print the result container
    function printResult() {
        // Store the current visibility state of the body and other elements
        const originalVisibility = document.body.style.visibility;
        document.body.style.visibility = 'hidden'; // Hide everything temporarily

        // Clone the result container to print
        const resultClone = document.getElementById("resultContainer").cloneNode(true);

        // Remove the "Return to Game" and "Print Result" buttons from the clone
        const returnButton = resultClone.querySelector("#returnButton");
        const printButton = resultClone.querySelector("#printButton");

        if (returnButton) {
            returnButton.style.display = 'none'; // Hide the "Return to Game" button
        }
        if (printButton) {
            printButton.style.display = 'none'; // Hide the "Print Result" button
        }

        // Create a new window or use an iframe to isolate the content to print
        const printWindow = window.open('', '', 'width=400,height=400');
        printWindow.document.write('<html><head><title>Print Result</title><style>body {font-family: Arial, sans-serif;}</style></head><body>');
        printWindow.document.write(resultClone.outerHTML); // Write the cloned content
        printWindow.document.write('</body></html>');

        // Wait for content to load, then trigger the print dialog
        printWindow.document.close();
        printWindow.onload = function() {
            printWindow.print();
            printWindow.close(); // Close the print window after printing
        };

        // Restore the original visibility state of the page
        document.body.style.visibility = originalVisibility;
    }
});

